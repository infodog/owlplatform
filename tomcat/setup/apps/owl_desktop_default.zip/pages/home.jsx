//#import Util.js
//#import session.js

var m = $.params.m;
var targetAppId = $.params.appId;
SessionService.addSessionValue("_loginMerId",m,request,response);

var spec = $.getAppProgram(targetAppId,"spec.json");
if(!spec){
    out.print("error, not a valid owl app.");

}
else{
    var html = $.getProgram(appMd5,"index.html");
    html = html.replace(/@spec/g, spec);
    out.print(html);

}
