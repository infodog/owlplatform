//#import init/initCommunity.js

out.print("init success!");